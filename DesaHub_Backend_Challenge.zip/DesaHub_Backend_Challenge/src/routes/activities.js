const express = require('express');
const pool = require('../db');

const router = express.Router();
const ALLOWED_STATUSES = ['draft', 'published', 'cancelled', 'completed'];

function parseId(value) {
  if (!/^[1-9]\d*$/.test(value)) return null;
  const id = Number(value);
  return Number.isSafeInteger(id) ? id : null;
}

function validateActivity(body) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    return { error: 'Body harus berupa objek JSON.' };
  }
  const { category_id, title, description = null, event_date, location, status = 'published' } = body;

  if (!Number.isSafeInteger(category_id) || category_id <= 0) {
    return { error: 'category_id harus bilangan bulat positif.' };
  }
  if (typeof title !== 'string' || !title.trim() || title.trim().length > 160) {
    return { error: 'title wajib diisi dan maksimal 160 karakter.' };
  }
  if (description !== null && (typeof description !== 'string')) {
    return { error: 'description harus berupa teks atau null.' };
  }
  if (typeof location !== 'string' || !location.trim() || location.trim().length > 180) {
    return { error: 'location wajib diisi dan maksimal 180 karakter.' };
  }
  if (typeof event_date !== 'string' || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}$/.test(event_date)) {
    return { error: 'event_date harus berformat YYYY-MM-DDTHH:mm:ss (waktu lokal desa).' };
  }
  if (!ALLOWED_STATUSES.includes(status)) {
    return { error: 'status harus draft, published, cancelled, atau completed.' };
  }

  return {
    data: {
      category_id,
      title: title.trim(),
      description,
      event_date,
      location: location.trim(),
      status,
    }
  };
}

const activitySelect = `
  SELECT a.id, a.category_id, c.name AS category_name,
         a.title, a.description,
         to_char(a.event_date, 'YYYY-MM-DD"T"HH24:MI:SS') AS event_date,
         a.location, a.status, a.created_at,
         COUNT(r.id)::integer AS registered_count
  FROM activities a
  JOIN activity_categories c ON c.id = a.category_id
  LEFT JOIN registrations r ON r.activity_id = a.id
`;

// GET /api/activities - semua kegiatan
router.get('/', async (req, res, next) => {
  try {
    const result = await pool.query(`${activitySelect}
      GROUP BY a.id, c.name
      ORDER BY a.event_date ASC, a.id ASC`);
    res.json({ message: 'Daftar kegiatan berhasil diambil.', data: result.rows });
  } catch (error) { next(error); }
});

// GET /api/activities/:id - satu kegiatan
router.get('/:id', async (req, res, next) => {
  const id = parseId(req.params.id);
  if (!id) return res.status(400).json({ message: 'ID kegiatan tidak valid.' });
  try {
    const result = await pool.query(`${activitySelect}
      WHERE a.id = $1
      GROUP BY a.id, c.name`, [id]);
    if (!result.rowCount) return res.status(404).json({ message: 'Kegiatan tidak ditemukan.' });
    return res.json({ message: 'Detail kegiatan berhasil diambil.', data: result.rows[0] });
  } catch (error) { return next(error); }
});

// POST /api/activities - buat kegiatan
router.post('/', async (req, res, next) => {
  const validation = validateActivity(req.body);
  if (validation.error) return res.status(400).json({ message: validation.error });
  const { category_id, title, description, event_date, location, status } = validation.data;
  try {
    const result = await pool.query(
      `INSERT INTO activities (category_id, title, description, event_date, location, status)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING id, category_id, title, description,
         to_char(event_date, 'YYYY-MM-DD"T"HH24:MI:SS') AS event_date,
         location, status, created_at`,
      [category_id, title, description, event_date, location, status]
    );
    return res.status(201).json({ message: 'Kegiatan berhasil dibuat.', data: result.rows[0] });
  } catch (error) { return next(error); }
});

// PUT /api/activities/:id - ganti data kegiatan
router.put('/:id', async (req, res, next) => {
  const id = parseId(req.params.id);
  if (!id) return res.status(400).json({ message: 'ID kegiatan tidak valid.' });
  const validation = validateActivity(req.body);
  if (validation.error) return res.status(400).json({ message: validation.error });
  const { category_id, title, description, event_date, location, status } = validation.data;
  try {
    const result = await pool.query(
      `UPDATE activities
       SET category_id = $1, title = $2, description = $3,
           event_date = $4, location = $5, status = $6
       WHERE id = $7
       RETURNING id, category_id, title, description,
         to_char(event_date, 'YYYY-MM-DD"T"HH24:MI:SS') AS event_date,
         location, status, created_at`,
      [category_id, title, description, event_date, location, status, id]
    );
    if (!result.rowCount) return res.status(404).json({ message: 'Kegiatan tidak ditemukan.' });
    return res.json({ message: 'Kegiatan berhasil diperbarui.', data: result.rows[0] });
  } catch (error) { return next(error); }
});

// DELETE /api/activities/:id - hapus kegiatan
router.delete('/:id', async (req, res, next) => {
  const id = parseId(req.params.id);
  if (!id) return res.status(400).json({ message: 'ID kegiatan tidak valid.' });
  try {
    const result = await pool.query('DELETE FROM activities WHERE id = $1 RETURNING id, title', [id]);
    if (!result.rowCount) return res.status(404).json({ message: 'Kegiatan tidak ditemukan.' });
    return res.json({ message: 'Kegiatan berhasil dihapus.', data: result.rows[0] });
  } catch (error) { return next(error); }
});

module.exports = router;
