function errorHandler(error, req, res, next) {
  // PostgreSQL SQLSTATE: kesalahan pengguna yang umum.
  if (error.code === '23503') {
    return res.status(409).json({ message: 'Data terkait masih digunakan atau kategori tidak ditemukan.' });
  }
  if (error.code === '23505') {
    return res.status(409).json({ message: 'Data dengan nilai unik tersebut sudah ada.' });
  }
  if (['22P02', '22007', '22008', '23514', '23502', '22001'].includes(error.code)) {
    return res.status(400).json({ message: 'Data yang dikirim tidak valid.' });
  }
  console.error('Internal error:', error);
  return res.status(500).json({ message: 'Terjadi kesalahan server.' });
}

module.exports = errorHandler;
