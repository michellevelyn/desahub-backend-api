const express = require('express');
const pool = require('./db');
const activityRoutes = require('./routes/activities');
const errorHandler = require('./middleware/errorHandler');

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '100kb' }));

app.get('/', (req, res) => {
  res.json({ name: 'DesaHub API', version: '1.0.0', docs: 'README.md' });
});

app.get('/health', async (req, res) => {
  try {
    await pool.query('SELECT 1');
    res.json({ status: 'ok', database: 'connected' });
  } catch (error) {
    console.error('Health check failed:', error.message);
    res.status(503).json({ status: 'error', database: 'disconnected' });
  }
});

app.get('/api/categories', async (req, res, next) => {
  try {
    const result = await pool.query('SELECT id, name, description FROM activity_categories ORDER BY id');
    res.json({ data: result.rows });
  } catch (error) { next(error); }
});

app.use('/api/activities', activityRoutes);

app.use((req, res) => res.status(404).json({ message: 'Endpoint tidak ditemukan.' }));
app.use(errorHandler);

module.exports = app;
