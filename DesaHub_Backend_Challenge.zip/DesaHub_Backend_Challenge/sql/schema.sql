-- DesaHub - Skema PostgreSQL
-- Jalankan sekali dalam database desa_hub yang masih kosong.
-- Hubungan 1:1  : residents -> resident_profiles, registrations -> attendances
-- Hubungan 1:N  : hamlets -> residents, activity_categories -> activities,
--                  activities -> announcements
-- Hubungan M:N  : residents <-> activities melalui registrations

CREATE TABLE hamlets (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT
);

CREATE TABLE residents (
    id BIGSERIAL PRIMARY KEY,
    hamlet_id BIGINT NOT NULL REFERENCES hamlets(id) ON DELETE RESTRICT,
    full_name VARCHAR(120) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    phone VARCHAR(30),
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE resident_profiles (
    id BIGSERIAL PRIMARY KEY,
    resident_id BIGINT NOT NULL UNIQUE REFERENCES residents(id) ON DELETE CASCADE,
    address TEXT NOT NULL,
    occupation VARCHAR(100),
    emergency_contact VARCHAR(30)
);

CREATE TABLE activity_categories (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT
);

CREATE TABLE activities (
    id BIGSERIAL PRIMARY KEY,
    category_id BIGINT NOT NULL REFERENCES activity_categories(id) ON DELETE RESTRICT,
    title VARCHAR(160) NOT NULL,
    description TEXT,
    event_date TIMESTAMP NOT NULL,
    location VARCHAR(180) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'published'
        CHECK (status IN ('draft', 'published', 'cancelled', 'completed')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE registrations (
    id BIGSERIAL PRIMARY KEY,
    resident_id BIGINT NOT NULL REFERENCES residents(id) ON DELETE RESTRICT,
    activity_id BIGINT NOT NULL REFERENCES activities(id) ON DELETE RESTRICT,
    registration_status VARCHAR(20) NOT NULL DEFAULT 'registered'
        CHECK (registration_status IN ('registered', 'cancelled')),
    registered_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (resident_id, activity_id)
);

CREATE TABLE announcements (
    id BIGSERIAL PRIMARY KEY,
    activity_id BIGINT NOT NULL REFERENCES activities(id) ON DELETE RESTRICT,
    title VARCHAR(160) NOT NULL,
    content TEXT NOT NULL,
    published_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE attendances (
    id BIGSERIAL PRIMARY KEY,
    registration_id BIGINT NOT NULL UNIQUE REFERENCES registrations(id) ON DELETE CASCADE,
    is_present BOOLEAN NOT NULL DEFAULT FALSE,
    checked_in_at TIMESTAMPTZ
);

CREATE INDEX idx_residents_hamlet ON residents(hamlet_id);
CREATE INDEX idx_activities_category_date ON activities(category_id, event_date);
CREATE INDEX idx_registrations_activity ON registrations(activity_id);
CREATE INDEX idx_announcements_activity ON announcements(activity_id);
